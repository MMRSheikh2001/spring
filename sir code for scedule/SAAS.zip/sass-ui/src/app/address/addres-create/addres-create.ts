
import { Component } from '@angular/core';
import { FormBuilder, FormGroup, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';

@Component({
  selector: 'app-addres-create',
  imports: [FormsModule, ReactiveFormsModule],
  templateUrl: './addres-create.html',
  styleUrl: './addres-create.css',
})
export class AddresCreate {



  addressForm!: FormGroup;
  states: string[] = [];

  countryStateMap: any = {
    BD: ['Dhaka', 'Chattogram', 'Rajshahi', 'Khulna', 'Sylhet'],
    US: ['California', 'Texas', 'New York', 'Florida'],
    IN: ['Maharashtra', 'Karnataka', 'Delhi', 'Tamil Nadu']
  };

  countryMap: any = {
    BD: 'Bangladesh',
    US: 'United States',
    IN: 'India'
  };

  constructor(private fb: FormBuilder) { }

  ngOnInit(): void {
    this.addressForm = this.fb.group({
      name: ['', Validators.required],
      addressLine1: ['', Validators.required],
      addressLine2: [''],
      city: ['', Validators.required],
      state: ['', Validators.required],
      postalCode: ['', Validators.required],
      country: ['', Validators.required]
    });

    this.addressForm.get('country')?.valueChanges.subscribe(code => {
      this.states = this.countryStateMap[code] || [];
      this.addressForm.get('state')?.reset();
    });
  }

  get f() {
    return this.addressForm.controls;
  }

  submit() {
    if (this.addressForm.invalid) {
      this.addressForm.markAllAsTouched();
      return;
    }

    console.log('JSON for API:', this.addressForm.value);
    alert('Address saved! Check console.');
  }

  formatAddress(): string {
    const a = this.addressForm.value;
    if (!a.name) return '';

    return `${a.name}
${a.addressLine1}
${a.addressLine2 || ''}
${a.city}, ${a.state} ${a.postalCode}
${this.countryMap[a.country] || ''}`;
  }

}
