import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddresCreate } from './addres-create';

describe('AddresCreate', () => {
  let component: AddresCreate;
  let fixture: ComponentFixture<AddresCreate>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [AddresCreate]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AddresCreate);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
