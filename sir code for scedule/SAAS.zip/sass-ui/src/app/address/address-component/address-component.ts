import { ChangeDetectorRef, Component, OnInit } from '@angular/core';

import { FormsModule } from '@angular/forms';
import { LocationLabel } from '../../model/location-label.model';
import { Country } from '../../model/country.model';
import { LocationService } from '../../services/location-service';
import { Location as MyLocation } from '../../model/location.model';
import { Address } from '../../model/address.model';
import { AddressService } from '../../services/address-service';



@Component({
  selector: 'app-address-component',
  standalone: true, // <-- if using standalone component
  imports: [FormsModule],
  templateUrl: './address-component.html',
  styleUrls: ['./address-component.css'],
})
export class AddressComponent implements OnInit {

  locationMap = new Map<number, string>();
  addressLine1 = '';
  addressLine2 = '';
  postalCode = '';

  addresses: Address[] = [];

  // temporary (later from JWT)
  userId = 1;

  countries: Country[] = [];
  locationLabels: LocationLabel = {};

  admin1List: MyLocation[] = [];
  admin2List: MyLocation[] = [];
  admin3List: MyLocation[] = [];

  selectedCountry?: string;
  selectedAdmin1?: number;
  selectedAdmin2?: number;
  selectedAdmin3?: number;

  // constructor(private locationService: LocationService, private cd: ChangeDetectorRef) { }

  constructor(
    private locationService: LocationService,
    private addressService: AddressService,
    private cd: ChangeDetectorRef
  ) { }

  ngOnInit(): void {
    this.locationService.getCountries().subscribe(data => this.countries = data);

    this.locationService.getCountries().subscribe({

      next: (data) => {
        this.countries = data;
        this.cd.markForCheck();
      }

    });
    this.loadAddresses();
  }

  onCountryChange(countryCode: string) {

    if (!countryCode) return;
    this.selectedCountry = countryCode;

    this.locationService.getLocationLabels(countryCode).subscribe(labels => {
      this.locationLabels = labels;
      this.cd.markForCheck(); // <--- trigger change detection
    });

    this.locationService.getAdminLevel1(countryCode).subscribe(list => {
      this.admin1List = list.map(l => this.mapLocation(l));
      this.admin2List = [];
      this.admin3List = [];
      this.selectedAdmin1 = undefined;
      this.selectedAdmin2 = undefined;
      this.selectedAdmin3 = undefined;
    });
  }

  onAdmin1Change(admin1Id: number) {
    if (!admin1Id) return;
    this.selectedAdmin1 = admin1Id;

    this.locationService.getChildren(admin1Id).subscribe(list => {
      this.admin2List = list.map(l => this.mapLocation(l));
      this.admin3List = [];
      this.selectedAdmin2 = undefined;
      this.selectedAdmin3 = undefined;

      // Trigger change detection
      this.cd.markForCheck();
    });
  }


  onAdmin2Change(admin2Id: number) {
    if (!admin2Id) return;
    this.selectedAdmin2 = admin2Id;

    this.locationService.getChildren(admin2Id).subscribe(list => {
      this.admin3List = list.map(l => this.mapLocation(l));
      this.selectedAdmin3 = undefined;

      // Trigger change detection
      this.cd.markForCheck();
    });
  }




  private mapLocation(l: Partial<MyLocation>): MyLocation {
    if (l.id && l.name) {
      this.locationMap.set(l.id, l.name);
    }

    return {
      id: l.id ?? 0,
      name: l.name ?? '',
      level: l.level ?? '',
      parent_id: l.parent_id,
      country_id: l.country_id ?? 0
    };
  }


loadAddresses() {
  this.addressService.getByUser(1)
    .subscribe(res => {
      this.addresses = res;
      this.cd.markForCheck(); // ensure Angular detects changes
    });
}

  saveAddress() {
    if (!this.selectedCountry || !this.addressLine1) {
      alert('Country and Address Line 1 are required');
      return;
    }

    const payload: Address = {
      userId: this.userId,
      countryCode: this.selectedCountry,
      admin1Id: this.selectedAdmin1,
      admin2Id: this.selectedAdmin2,
      admin3Id: this.selectedAdmin3,
      addressLine1: this.addressLine1,
      addressLine2: this.addressLine2,
      postalCode: this.postalCode
    };

    this.addressService.save(payload).subscribe(() => {
      this.resetForm();
      this.loadAddresses();
    });
  }


  resetForm() {
    this.addressLine1 = '';
    this.addressLine2 = '';
    this.postalCode = '';
  }

  getLocationName(id?: number): string | null {
    if (!id) return null;
    return this.locationMap.get(id) ?? null;
  }


}
