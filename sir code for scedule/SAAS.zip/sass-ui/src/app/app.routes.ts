import { Routes } from '@angular/router';
import { Login } from './auth/login/login';
import { Register } from './auth/register/register';
import { HomeComponent } from './home/home-component/home-component';

import { Dashboard } from './dashboard/dashboard/dashboard';
import { authGuard } from './auth/auth.guard';

import { AddressComponent } from './address/address-component/address-component';
import { ProfileComponent } from './auth/profile-component/profile-component';
import { CreateUserProfile } from './auth/create-user-profile/create-user-profile';

export const routes: Routes = [
    { path: 'login', component: Login },
    { path: 'register', component: Register },
    { path: 'profile', component: ProfileComponent, canActivate: [authGuard] },
    { path: 'createprofile', component: CreateUserProfile, canActivate: [authGuard] },
    { path: '', component: AddressComponent },
    { path: '', redirectTo: 'login', pathMatch: 'full' },
    
    // { path: 'dashboard', component:Dashboard},
    {
    path: 'dashboard',
    component: Dashboard,
    canActivate: [authGuard], // protect dashboard
  },
];
