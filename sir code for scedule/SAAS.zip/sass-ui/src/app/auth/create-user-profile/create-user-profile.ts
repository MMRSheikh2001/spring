import { Component } from '@angular/core';
import { UserProfileRequest } from '../../model/userProfileRequest';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { UserProfile } from '../../model/userProfile.model';
import { UserProfileService } from '../../services/user-profile-service';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

@Component({
  selector: 'app-create-user-profile',
  imports: [CommonModule, FormsModule, ReactiveFormsModule],
  templateUrl: './create-user-profile.html',
  styleUrls: ['./create-user-profile.css'], // fixed styleUrls
})
export class CreateUserProfile {

  profileForm!: FormGroup;
  profile!: UserProfile;

  selectedFile?: File; // <-- store selected file

  bloodGroups = [
    'A_POS', 'A_NEG',
    'B_POS', 'B_NEG',
    'AB_POS', 'AB_NEG',
    'O_POS', 'O_NEG'
  ];

  constructor(private fb: FormBuilder, private profileService: UserProfileService) { }

  ngOnInit(): void {
    this.profileForm = this.fb.group({
      firstName: ['', Validators.required],
      lastName: ['', Validators.required],
      dateOfBirth: [''],
      gender: ['', Validators.required],
      phone: ['', Validators.required],
      picture: [''], // still keep string for display
      bloodGroup: [''],
      lastBloodDonationDate: [''],
      willingToDonateBlood: [false],
      spouseName: [''],
      spousePhone: [''],
      emailNotifications: [true],
      bloodDonationReminders: [true]
    });

    // Load existing profile
    this.profileService.getMyProfile().subscribe({
      next: (res) => {
        this.profile = res;
        this.profileForm.patchValue(res); // auto-fill form
      },
      error: (err) => console.warn('No profile found yet', err)
    });
  }

  // File input change event
  onFileSelected(event: Event) {
    const input = event.target as HTMLInputElement;
    if (input.files && input.files.length > 0) {
      this.selectedFile = input.files[0];
      console.log('Selected file:', this.selectedFile.name);
    }
  }

  onSubmit() {
    const payload: UserProfileRequest = this.profileForm.value;

    // Send FormData with JSON + file
    this.profileService.saveProfile(payload, this.selectedFile).subscribe({
      next: (res) => {
        alert('Profile saved!');
        this.profile = res;
      },
      error: (err) => console.error('Error saving profile', err)
    });
  }
}
