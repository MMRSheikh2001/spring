import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CreateUserProfile } from './create-user-profile';

describe('CreateUserProfile', () => {
  let component: CreateUserProfile;
  let fixture: ComponentFixture<CreateUserProfile>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [CreateUserProfile]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CreateUserProfile);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
