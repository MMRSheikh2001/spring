import { CanActivateFn, Router } from '@angular/router';
import { inject } from '@angular/core';

import { Observable, map, of } from 'rxjs';
import { Auth } from '../services/auth';

export const authGuard: CanActivateFn = () => {
  const auth = inject(Auth);
  const router = inject(Router);

  return auth.checkAuth().pipe(   // 🔥 CALL BACKEND
    map(isAuth => {
      if (!isAuth) {
        router.navigate(['/login']);
        return false;
      }
      return true;
    })
  );
};
