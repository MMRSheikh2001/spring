import { ChangeDetectorRef, Component, inject } from '@angular/core';
import { UserProfile } from '../../model/userProfile.model';
import { HttpErrorResponse } from '@angular/common/http';
import { UserProfileService } from '../../services/user-profile-service';
import { Router } from '@angular/router';
import { CommonModule } from '@angular/common';


@Component({
  selector: 'app-profile-component',
  imports: [CommonModule],
  templateUrl: './profile-component.html',
  styleUrl: './profile-component.css',
})
export class ProfileComponent {



  private userProfileService = inject(UserProfileService);
  private cdr = inject(ChangeDetectorRef);
  private router = inject(Router);

  profile!: UserProfile;
  loading = true;
  errorMsg = '';

  ngOnInit(): void {
  this.userProfileService.getMyProfile().subscribe({
    next: (res: UserProfile) => {
      this.profile = res;
      this.loading = false;
      this.cdr.markForCheck();
    },
    error: (err: HttpErrorResponse) => {
      console.error('Profile load error:', err);
      this.errorMsg = 'Failed to load profile';
      this.loading = false;

      if (err.status === 401 || err.status === 403) {
        // Not authenticated → redirect to login
        this.router.navigate(['/login']);
      }
    }
  });
}

}
