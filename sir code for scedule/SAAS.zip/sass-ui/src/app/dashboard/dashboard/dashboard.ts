import { AfterViewInit, Component, inject } from '@angular/core';
import { Router } from '@angular/router';
import { Auth } from '../../services/auth';
import { Chart, BarController, CategoryScale, LinearScale, BarElement, Title, Tooltip, Legend } from 'chart.js';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-dashboard',
  imports: [CommonModule],
  templateUrl: './dashboard.html',
  styleUrl: './dashboard.css',
})
export class Dashboard implements AfterViewInit {

  private router = inject(Router);
  private authService = inject(Auth);

  email = localStorage.getItem('email');
  role = localStorage.getItem('role');

  sidebarCollapsed = false;

  dashboardCards = [
    { title: 'Users', value: 120, icon: 'bi bi-people-fill' },
    { title: 'Reports', value: 45, icon: 'bi bi-file-earmark-text' },
    { title: 'Revenue', value: '$12,000', icon: 'bi bi-currency-dollar' },
    { title: 'Active Sessions', value: 32, icon: 'bi bi-clock' },
  ];

  logout() {
    this.authService.logout();
    this.router.navigate(['/login']);
  }

  ngAfterViewInit(): void {
    this.registerChartJs();
    this.initChart();
  }

  // ✅ Register chart.js controllers, elements, scales, and plugins
  registerChartJs() {
    Chart.register(
      BarController,
      CategoryScale,
      LinearScale,
      BarElement,
      Title,
      Tooltip,
      Legend
    );
  }

  initChart() {
    const ctx = document.getElementById('userChart') as HTMLCanvasElement;
    if (!ctx) return;

    new Chart(ctx, {
      type: 'bar',
      data: {
        labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
        datasets: [
          {
            label: 'New Users',
            data: [12, 19, 3, 5, 2, 3],
            backgroundColor: 'rgba(54, 162, 235, 0.6)',
          },
        ],
      },
      options: {
        responsive: true,
        plugins: {
          legend: {
            display: true,
            position: 'top',
          },
        },
      },
    });
  }
}
