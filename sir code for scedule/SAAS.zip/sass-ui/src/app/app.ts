import { Component, OnInit, signal } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { Auth } from './services/auth';

@Component({
  selector: 'app-root',
  imports: [RouterOutlet],
  templateUrl: './app.html',
  styleUrl: './app.css'
})
export class App implements OnInit{
  protected readonly title = signal('sass-ui');

  constructor(private auth: Auth) {}

  ngOnInit() {
    this.auth.checkAuth().subscribe(); // initialize authState$
  }
}
