import { ApplicationConfig, provideBrowserGlobalErrorListeners, provideZonelessChangeDetection } from '@angular/core';
import { provideRouter } from '@angular/router';

import { routes } from './app.routes';
import { provideHttpClient, withInterceptors, withXsrfConfiguration } from '@angular/common/http';
import { jwtInterceptor } from './services/jwt.interceptor';

export const appConfig: ApplicationConfig = {
  providers: [
    provideBrowserGlobalErrorListeners(),
    provideZonelessChangeDetection(),
    provideRouter(routes),
    provideHttpClient(
      withInterceptors([jwtInterceptor]),
        withXsrfConfiguration({
        cookieName: 'XSRF-TOKEN',  // Spring's CSRF cookie name
        headerName: 'X-XSRF-TOKEN' // Header Angular will send automatically
      }),
    ),

  
    
  ]
};
