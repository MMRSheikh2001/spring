import { Injectable } from '@angular/core';
import {
  HttpEvent,
  HttpInterceptorFn,
  HttpRequest,
  HttpHandler
} from '@angular/common/http';
import { Observable } from 'rxjs';

export const jwtInterceptor: HttpInterceptorFn = (req, next) => {

  // Clone request and enable cookie sending
  const authReq = req.clone({
    withCredentials: true
  });

  return next(authReq);
};
