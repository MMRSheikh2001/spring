import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Address } from '../model/address.model';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class AddressService {
  

  private baseUrl = 'http://localhost:8085/api/addresses';

  constructor(private http: HttpClient) {}

  save(address: Address): Observable<Address> {
    return this.http.post<Address>(this.baseUrl, address);
  }

  getByUser(userId: number): Observable<Address[]> {
    return this.http.get<Address[]>(`${this.baseUrl}/user/${userId}`);
  }


}
