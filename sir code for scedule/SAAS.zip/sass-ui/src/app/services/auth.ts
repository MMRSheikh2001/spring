import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { BehaviorSubject, catchError, map, Observable, of, tap } from 'rxjs';
import { AuthResponse } from '../model/auth-response.model';

@Injectable({
  providedIn: 'root',
})
export class Auth {


  
private api = 'http://localhost:8085/api/auth';
  private profileApi = 'http://localhost:8085/api/profiles';

  // ✅ Auth state observable
  private authState$ = new BehaviorSubject<boolean>(false);

  constructor(private http: HttpClient) {}

  /**
   * 🔐 LOGIN
   * Backend sets HttpOnly cookie
   */
  login(data: { email: string; password: string }): Observable<boolean> {
    return this.http.post<AuthResponse>(`${this.api}/login`, data, { withCredentials: true }).pipe(
      map(() => true),
      tap(() => this.authState$.next(true)),
      catchError(() => {
        this.authState$.next(false);
        return of(false);
      })
    );
  }

  /**
   * 🔐 LOGOUT
   * Backend clears cookie
   */
  logout(): Observable<boolean> {
    return this.http.post(`${this.api}/logout`, {}, { withCredentials: true }).pipe(
      tap(() => this.authState$.next(false)),
      map(() => true),
      catchError(() => {
        this.authState$.next(false);
        return of(false);
      })
    );
  }

  



checkAuth(): Observable<boolean> {
  return this.http.get(`${this.api}/me`, { withCredentials: true }).pipe(
    map(() => true), // logged in
    tap(() => this.authState$.next(true)),
    catchError(() => {
      this.authState$.next(false);
      return of(false);
    })
  );
}


  /**
   * 📝 REGISTER
   */
  register(data: { name: string; email: string; phone: string; password: string }): Observable<boolean> {
    return this.http.post(`${this.api}/register`, data, { withCredentials: true }).pipe(
      map(() => true),
      catchError(() => of(false))
    );
  }

  /**
   * ✅ Observable auth state for guards or components
   */
  isLoggedIn(): Observable<boolean> {
    return this.authState$.asObservable();
  }


}