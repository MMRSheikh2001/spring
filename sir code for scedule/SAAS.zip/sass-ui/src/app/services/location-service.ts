import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Country } from '../model/country.model';
import { Observable } from 'rxjs';
import { LocationLabel } from '../model/location-label.model';

 import { Location as MyLocation } from '../model/location.model';

@Injectable({
  providedIn: 'root',
})
export class LocationService {


  private baseUrl = 'http://localhost:8085/api'; // Your Spring Boot API base URL

  constructor(private http: HttpClient) { }

  getCountries(): Observable<Country[]> {
    return this.http.get<Country[]>(`${this.baseUrl}/countries`);
  }

  getLocationLabels(countryCode: string): Observable<LocationLabel> {
    return this.http.get<LocationLabel>(`${this.baseUrl}/locations/labels/${countryCode}`);
  }

  getAdminLevel1(countryCode: string): Observable<MyLocation[]> {
    return this.http.get<MyLocation[]>(`${this.baseUrl}/locations/admin1/${countryCode}`);
  }

  getChildren(parentId: number): Observable<MyLocation[]> {
    return this.http.get<MyLocation[]>(`${this.baseUrl}/locations/children/${parentId}`);
  }

}
