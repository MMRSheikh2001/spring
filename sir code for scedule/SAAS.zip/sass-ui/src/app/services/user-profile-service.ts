import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { UserProfile } from '../model/userProfile.model';
import { map, Observable } from 'rxjs';
import { UserProfileRequest } from '../model/userProfileRequest';

@Injectable({
  providedIn: 'root',
})
export class UserProfileService {


  private api = 'http://localhost:8085/api/profiles';

  constructor(private http: HttpClient) { }

  // getMyProfile(): Observable<UserProfile> {
  //   return this.http.get<UserProfile>(`${this.api}/me`, { withCredentials: true });
  // }


  getMyProfile(): Observable<UserProfile> {
  return this.http.get<UserProfile>(`${this.api}/me`, { withCredentials: true }).pipe(
    map(profile => {
      if (profile.picture) {
        profile.picture = `http://localhost:8085/images/${profile.picture}`;
      }
      return profile;
    })
  );
}



  // saveProfile(profile: UserProfileRequest): Observable<UserProfile> {
  //   return this.http.post<UserProfile>(`${this.api}/me`, profile, { withCredentials: true });
  // }

saveProfile(profile: UserProfileRequest, file?: File): Observable<UserProfile> {
  const formData = new FormData();

  // Add JSON as Blob
  formData.append('profile', new Blob([JSON.stringify(profile)], { type: 'application/json' }));

  // Add file if exists
  if (file) {
    formData.append('file', file);
  }

  return this.http.post<UserProfile>(`${this.api}/me`, formData, { withCredentials: true });
}


  /**
   * OPTIONAL: Delete user's profile (if needed)
   */
  deleteProfile(): Observable<void> {
    return this.http.delete<void>(`${this.api}/me`, { withCredentials: true });
  }



}
