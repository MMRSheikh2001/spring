// country.model.ts
export interface Country {
  code: string;
  name: string;
}

