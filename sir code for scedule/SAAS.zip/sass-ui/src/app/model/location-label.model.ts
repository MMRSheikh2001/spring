
export interface LocationLabel {
  [level: string]: string; // Example: { ADMIN_LEVEL_1: 'State', ADMIN_LEVEL_2: 'County' }
}
