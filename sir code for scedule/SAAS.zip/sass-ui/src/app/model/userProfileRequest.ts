export interface UserProfileRequest {
  firstName: string;
  lastName: string;
  dateOfBirth: string; // "YYYY-MM-DD"
  gender: 'MALE' | 'FEMALE' | 'OTHER';
  phone: string;
  picture?: string | null;

  bloodGroup?:
    | 'A_POS' | 'A_NEG'
    | 'B_POS' | 'B_NEG' 
    | 'AB_POS' | 'AB_NEG'
    | 'O_POS' | 'O_NEG';

  lastBloodDonationDate?: string | null;
  willingToDonateBlood?: boolean;

  spouseName?: string | null;
  spousePhone?: string | null;

  emailNotifications?: boolean;
  bloodDonationReminders?: boolean;
}
