export interface Address {
  id?: number;
  userId: number;
  countryCode: string;
  admin1Id?: number;
  admin1Name?: string; // Division / State
  admin2Id?: number;
  admin2Name?: string; // District / County
  admin3Id?: number;
  admin3Name?: string; // City / Upazila
  addressLine1: string;
  addressLine2?: string;
  postalCode?: string;
}
