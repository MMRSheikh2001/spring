export interface UserProfile {
  id: number;
  firstName: string;
  lastName: string;
  fullName: string;
  dateOfBirth: string;
  gender: string;
  phone: string;
  picture: string | null;
  bloodGroup: string;
  lastBloodDonationDate: string | null;
  nextBloodDonationDate: string | null;
  willingToDonateBlood: boolean;
  spouseName: string | null;
  spousePhone: string | null;
  emailNotifications: boolean;
  bloodDonationReminders: boolean;
  active: boolean;
  createdAt: string;
  updatedAt: string;
}