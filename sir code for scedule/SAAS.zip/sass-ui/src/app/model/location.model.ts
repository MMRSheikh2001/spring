export interface Location {
  id: number;
  name: string;
  level: string;
  parent_id?: number;
  country_id: number;
}